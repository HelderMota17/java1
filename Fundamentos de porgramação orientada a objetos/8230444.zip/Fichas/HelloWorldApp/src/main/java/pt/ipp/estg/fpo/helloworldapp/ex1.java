/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pt.ipp.estg.fpo.helloworldapp;

public class ex1 
{
   public static void main(String[] args)
  {
   
    char l = 'l', p = 'p';
    int q = 4, d = 2;
    System.out.println(l);
    System.out.println(p);
    System.out.println(d);
    System.out.println(q);
    System.out.println(l + p + 2);
    System.out.println("" + l + p + 2);
    System.out.println(q + d);
    System.out.println("");
    
    int[] arrayint = new int[5];
    arrayint = new int [5];
    arrayint[0]= 0;
    arrayint[0]= 1;
    arrayint[0]= 2;
    arrayint[0]= 3;
    arrayint[0]= 4;
    
    System.out.println(arrayint[2]);
    
    float[] arrayfloat = new float[5];
    arrayfloat = new float [5];
    arrayfloat[0]= 0;
    arrayfloat[0]= 1;
    arrayfloat[0]= 2;
    arrayfloat[0]= 3;
    arrayfloat[0]= 4;
    
    System.out.println(arrayint[2]);
  }
 
    
}
