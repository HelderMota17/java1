/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pt.ipp.estg.fpo.helloworldapp;

/**
 *
 * @author helde
 */
public class ex5 
{
        public static void main(String [] atgs)
    {
       long valor = 0;
        System.out.println(valor);
        valor = 3;
        System.out.println(valor);
        boolean valor2 = true;
        System.out.println(valor2);

        
    }
    
}
