package pt.ipp.estg.fpo.helloworldapp;

public class HelloWorldApp 
{

    public static void main(String[] args)
    {
        // TODO code application logic here
        System.out.println("Hello World!");
    }
}
