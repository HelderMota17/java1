/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pt.ipp.estg.fpo.helloworldapp;

/**
 *
 * @author helde
 */
public class ex4 {
    public static void main(String [] atgs)
    {
       int v = 0;
        v++;

        int amount = v++;
        System.out.println(++v + " " + amount);
        System.out.println(v);

        
    }
}
