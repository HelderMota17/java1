/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pt.ipp.estg.fpo.helloworldapp;

/**
 *
 * @author helde
 */
public class NewClass 
{
   public static void main(String[] args)
    {
        // TODO code application logic here
       
        int numero = 10;
          char carecter = 'A';
        
        System.out.println("Saudações ");
    } 
}
